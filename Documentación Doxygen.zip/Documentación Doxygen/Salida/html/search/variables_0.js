var searchData=
[
  ['_5fksorpresa_215',['_Ksorpresa',['../class_sorpresa.html#a4d5c9619869d8da5e5cfcacae65390e8',1,'Sorpresa']]]
];
