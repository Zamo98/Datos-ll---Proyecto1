var searchData=
[
  ['iniciar_188',['Iniciar',['../class_juego.html#a6670887ef94fe76700eb7e6cfc3272a6',1,'Juego']]],
  ['internos_189',['Internos',['../class_internos.html#aeb9ed946f6f2addadbf13ba16782dc4e',1,'Internos']]]
];
