var searchData=
[
  ['velocidadx_260',['velocidadX',['../class_bola.html#aa941a075f38c3285984aff29bfb5f0da',1,'Bola']]],
  ['velocidady_261',['velocidadY',['../class_bola.html#a1c502b8f15fa823a53dafdbd34fd4d57',1,'Bola']]],
  ['vida_262',['Vida',['../class_dobles.html#a18c71ff663ed19c0950e28cdbf43a54d',1,'Dobles::Vida()'],['../class_triples.html#a00680b8a82a212d1e9f99bf533e161f7',1,'Triples::Vida()']]],
  ['vx_263',['vX',['../class_bola.html#af4c72f502892a6128aa625d77001bb92',1,'Bola']]],
  ['vy_264',['vY',['../class_bola.html#acc566694008bb3465778acc012e99ba6',1,'Bola']]]
];
