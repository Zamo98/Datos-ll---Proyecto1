var searchData=
[
  ['keypressevent_65',['keyPressEvent',['../class_juego.html#aca9e4c0f4a6698500fec4e59d1ef3d6a',1,'Juego']]],
  ['ksorpresa_66',['KSorpresa',['../class_sorpresa.html#a0d7c2aa7fb4daa56d0f9ab0bda2eac3d',1,'Sorpresa']]]
];
