var searchData=
[
  ['nombrejuego_80',['nombreJuego',['../ventana_8cpp.html#a0e63e6a6e111d9a85310b23d6aa9d295',1,'nombreJuego():&#160;ventana.cpp'],['../ventana_8h.html#a0e63e6a6e111d9a85310b23d6aa9d295',1,'nombreJuego():&#160;ventana.cpp']]],
  ['nuevoancho_81',['nuevoAncho',['../class_raqueta.html#aec29e6a7fc259ee47b2ac6a18cabf4f7',1,'Raqueta']]]
];
