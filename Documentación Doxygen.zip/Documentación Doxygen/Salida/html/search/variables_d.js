var searchData=
[
  ['scene_253',['scene',['../class_juego.html#a914c8c3c8b1f40c4f2c13432939659d6',1,'Juego']]],
  ['sorpresa_254',['sorpresa',['../class_juego.html#a95aee64042eb0159fc1afcad20119199',1,'Juego::sorpresa()'],['../bola_8cpp.html#a5ae40864b3af151ff9e2b4b67b6623ff',1,'sorpresa():&#160;bola.cpp']]],
  ['sorpresax_255',['SorpresaX',['../bloques___b_a_c_k_u_p__9669_8cpp.html#a7ca307bec6dbc8ddb220c3cc2dad2c21',1,'SorpresaX():&#160;bloques_BACKUP_9669.cpp'],['../bloques___b_a_c_k_u_p__9743_8cpp.html#a7ca307bec6dbc8ddb220c3cc2dad2c21',1,'SorpresaX():&#160;bloques_BACKUP_9743.cpp'],['../bloques___r_e_m_o_t_e__9669_8cpp.html#a7ca307bec6dbc8ddb220c3cc2dad2c21',1,'SorpresaX():&#160;bloques_REMOTE_9669.cpp'],['../bloques___r_e_m_o_t_e__9743_8cpp.html#a7ca307bec6dbc8ddb220c3cc2dad2c21',1,'SorpresaX():&#160;bloques_REMOTE_9743.cpp']]],
  ['sorpresay_256',['SorpresaY',['../bloques___b_a_c_k_u_p__9669_8cpp.html#a17a00f08cf46e055cc1646ace529d66c',1,'SorpresaY():&#160;bloques_BACKUP_9669.cpp'],['../bloques___b_a_c_k_u_p__9743_8cpp.html#a17a00f08cf46e055cc1646ace529d66c',1,'SorpresaY():&#160;bloques_BACKUP_9743.cpp'],['../bloques___r_e_m_o_t_e__9669_8cpp.html#a17a00f08cf46e055cc1646ace529d66c',1,'SorpresaY():&#160;bloques_REMOTE_9669.cpp'],['../bloques___r_e_m_o_t_e__9743_8cpp.html#a17a00f08cf46e055cc1646ace529d66c',1,'SorpresaY():&#160;bloques_REMOTE_9743.cpp']]]
];
