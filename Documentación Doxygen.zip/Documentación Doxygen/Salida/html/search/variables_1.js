var searchData=
[
  ['ancho_216',['ancho',['../class_raqueta.html#a6e14b951dd044e9afe6459efbdddd989',1,'Raqueta']]],
  ['anchobola_217',['anchoBola',['../class_bola.html#a0a0093cc790c407b4e0e7fe246477755',1,'Bola']]],
  ['anchoventana_218',['anchoVentana',['../ventana_8cpp.html#a5f7bfdaf44e61e39e4cd28cd00f90294',1,'anchoVentana():&#160;ventana.cpp'],['../ventana_8h.html#a5f7bfdaf44e61e39e4cd28cd00f90294',1,'anchoVentana():&#160;ventana.cpp']]]
];
