var searchData=
[
  ['ventana_213',['Ventana',['../class_ventana.html#a890557b1c517d9b890dcb2e9663a558c',1,'Ventana']]],
  ['vidas_214',['Vidas',['../class_dobles.html#a54be0e197995fd3c1eee0a4d74ef608e',1,'Dobles::Vidas()'],['../class_triples.html#ae533cc41916ae2b14bacb44dcae98ba2',1,'Triples::Vidas()']]]
];
