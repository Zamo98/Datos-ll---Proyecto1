var searchData=
[
  ['dobles_2ecpp_155',['dobles.cpp',['../dobles_8cpp.html',1,'']]],
  ['dobles_2eh_156',['dobles.h',['../dobles_8h.html',1,'']]]
];
