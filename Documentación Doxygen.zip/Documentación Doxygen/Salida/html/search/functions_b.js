var searchData=
[
  ['seguirraqueta_208',['seguirRaqueta',['../class_bola.html#aba41e492e50d7ef2bdfd5be45e53948c',1,'Bola::seguirRaqueta()'],['../class_bola.html#aba41e492e50d7ef2bdfd5be45e53948c',1,'Bola::seguirRaqueta()'],['../class_bola.html#aba41e492e50d7ef2bdfd5be45e53948c',1,'Bola::seguirRaqueta()']]],
  ['setlanzamiento_209',['setLanzamiento',['../class_bola.html#a572673e006f469160a624019eed2a4de',1,'Bola::setLanzamiento(bool value)'],['../class_bola.html#a572673e006f469160a624019eed2a4de',1,'Bola::setLanzamiento(bool value)'],['../class_bola.html#a572673e006f469160a624019eed2a4de',1,'Bola::setLanzamiento(bool value)'],['../class_bola.html#a572673e006f469160a624019eed2a4de',1,'Bola::setLanzamiento(bool value)'],['../class_bola.html#a572673e006f469160a624019eed2a4de',1,'Bola::setLanzamiento(bool value)']]],
  ['setpuntos_210',['setPuntos',['../class_juego.html#a34c1c31485c519ea15c84eee3093498b',1,'Juego']]],
  ['sorpresa_211',['Sorpresa',['../class_sorpresa.html#aabb41e647453a6ee50e99360b30180d8',1,'Sorpresa']]]
];
