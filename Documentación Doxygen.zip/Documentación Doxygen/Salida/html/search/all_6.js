var searchData=
[
  ['gameover_48',['gameOver',['../class_juego.html#ac9e2b6cb5ff6462952e1c1e965e6b6c3',1,'Juego']]],
  ['gamewin_49',['gameWin',['../class_juego.html#a19294e71b9c31ce09fc0f9d160229a1a',1,'Juego']]],
  ['gc_50',['gC',['../class_bola.html#a175e6df2996674b0e6ec345005647d17',1,'Bola']]],
  ['gd_51',['gD',['../class_bola.html#ab6398f8aaeb178617ce73cb0e7638611',1,'Bola']]],
  ['golpe_52',['golpe',['../class_bola.html#a97b1e44cd79bea7439ecc7f476168421',1,'Bola']]],
  ['gt_53',['gT',['../class_bola.html#aec4ad6cc5b87cc642dc01eafd2638e1f',1,'Bola']]]
];
