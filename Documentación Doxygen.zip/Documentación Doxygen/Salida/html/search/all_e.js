var searchData=
[
  ['raqueta_94',['Raqueta',['../class_raqueta.html',1,'Raqueta'],['../class_raqueta.html#ac0aed0b8ed54fec350763c007c24735b',1,'Raqueta::Raqueta()'],['../class_juego.html#adfd36e1c7e3c2d696511ceb911c29153',1,'Juego::raqueta()']]],
  ['raqueta_2ecpp_95',['raqueta.cpp',['../raqueta_8cpp.html',1,'']]],
  ['raqueta_2eh_96',['raqueta.h',['../raqueta_8h.html',1,'']]],
  ['readme_2emd_97',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['reducirbola_98',['reducirBola',['../class_bola.html#a3f09bc5d2438f8dd78720ca5a707c8fe',1,'Bola']]],
  ['reducirraqueta_99',['reducirRaqueta',['../class_raqueta.html#a5d233085c854f6fd006efd1c8353456f',1,'Raqueta']]]
];
