var searchData=
[
  ['lanzada_238',['lanzada',['../class_bola.html#ad28fa22de8ba29d6979b9aa9bc8d2782',1,'Bola']]],
  ['largo_239',['largo',['../class_raqueta.html#abeeee11ee94024b88c9684ad2958dd53',1,'Raqueta']]],
  ['largobola_240',['largoBola',['../class_bola.html#aa8f8a70cba325dd3cebde701ae9017a5',1,'Bola']]],
  ['largoventana_241',['largoVentana',['../ventana_8cpp.html#a525c1577b6e732f84fa65d0a214aa82d',1,'largoVentana():&#160;ventana.cpp'],['../ventana_8h.html#a525c1577b6e732f84fa65d0a214aa82d',1,'largoVentana():&#160;ventana.cpp']]]
];
