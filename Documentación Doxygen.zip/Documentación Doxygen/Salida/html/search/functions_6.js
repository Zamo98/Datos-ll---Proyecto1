var searchData=
[
  ['juego_190',['Juego',['../class_juego.html#ac596d8ae1dcb6dfbafb4533317330ddf',1,'Juego']]],
  ['juegoterminado_191',['juegoTerminado',['../class_juego.html#a2ae0c60f42d9f0e26f58db256c8c7c56',1,'Juego']]],
  ['jugadorgana_192',['jugadorGana',['../class_juego.html#aa7b769e6af6ee5c28bc218e1863f016d',1,'Juego']]]
];
