var searchData=
[
  ['triples_2ecpp_170',['triples.cpp',['../triples_8cpp.html',1,'']]],
  ['triples_2eh_171',['triples.h',['../triples_8h.html',1,'']]]
];
