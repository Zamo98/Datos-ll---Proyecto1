var searchData=
[
  ['cant_5fprofundidad_182',['cant_profundidad',['../class_profundos.html#a057ae50421c90095354940c7cc88fe20',1,'Profundos']]],
  ['comun_183',['Comun',['../class_comun.html#a69185084380a5e1e67d8268b440827a6',1,'Comun']]],
  ['crearbloque_184',['CrearBloque',['../class_juego.html#a5bb631f63c41bf881825aa9ede516961',1,'Juego']]]
];
