var searchData=
[
  ['raqueta_205',['Raqueta',['../class_raqueta.html#ac0aed0b8ed54fec350763c007c24735b',1,'Raqueta']]],
  ['reducirbola_206',['reducirBola',['../class_bola.html#a3f09bc5d2438f8dd78720ca5a707c8fe',1,'Bola']]],
  ['reducirraqueta_207',['reducirRaqueta',['../class_raqueta.html#a5d233085c854f6fd006efd1c8353456f',1,'Raqueta']]]
];
