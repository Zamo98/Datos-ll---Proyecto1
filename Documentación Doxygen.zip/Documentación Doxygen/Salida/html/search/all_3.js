var searchData=
[
  ['cant_5fprofundidad_31',['cant_profundidad',['../class_profundos.html#a057ae50421c90095354940c7cc88fe20',1,'Profundos']]],
  ['comun_32',['Comun',['../class_comun.html',1,'Comun'],['../class_juego.html#a550d48b5165f5e82c7b367a41cd7138c',1,'Juego::comun()'],['../class_comun.html#a69185084380a5e1e67d8268b440827a6',1,'Comun::Comun()']]],
  ['comun_2ecpp_33',['comun.cpp',['../comun_8cpp.html',1,'']]],
  ['comun_2eh_34',['comun.h',['../comun_8h.html',1,'']]],
  ['comunesx_35',['ComunesX',['../bloques___b_a_c_k_u_p__9669_8cpp.html#abda2f857a33e37628b12ac69cf24f508',1,'ComunesX():&#160;bloques_BACKUP_9669.cpp'],['../bloques___b_a_c_k_u_p__9743_8cpp.html#abda2f857a33e37628b12ac69cf24f508',1,'ComunesX():&#160;bloques_BACKUP_9743.cpp'],['../bloques___r_e_m_o_t_e__9669_8cpp.html#abda2f857a33e37628b12ac69cf24f508',1,'ComunesX():&#160;bloques_REMOTE_9669.cpp'],['../bloques___r_e_m_o_t_e__9743_8cpp.html#abda2f857a33e37628b12ac69cf24f508',1,'ComunesX():&#160;bloques_REMOTE_9743.cpp']]],
  ['comunesy_36',['ComunesY',['../bloques___b_a_c_k_u_p__9669_8cpp.html#ad55d34adf56f87e610dd7cb765963aa2',1,'ComunesY():&#160;bloques_BACKUP_9669.cpp'],['../bloques___b_a_c_k_u_p__9743_8cpp.html#ad55d34adf56f87e610dd7cb765963aa2',1,'ComunesY():&#160;bloques_BACKUP_9743.cpp'],['../bloques___r_e_m_o_t_e__9669_8cpp.html#ad55d34adf56f87e610dd7cb765963aa2',1,'ComunesY():&#160;bloques_REMOTE_9669.cpp'],['../bloques___r_e_m_o_t_e__9743_8cpp.html#ad55d34adf56f87e610dd7cb765963aa2',1,'ComunesY():&#160;bloques_REMOTE_9743.cpp']]],
  ['contador_37',['contador',['../class_juego.html#aa1b02a0c5aacd7001acd76e984b7b945',1,'Juego']]],
  ['crearbloque_38',['CrearBloque',['../class_juego.html#a5bb631f63c41bf881825aa9ede516961',1,'Juego']]]
];
