var searchData=
[
  ['doble_226',['doble',['../class_juego.html#a8d000953a610e47eb62d646d7c0106f8',1,'Juego']]],
  ['doblesx_227',['DoblesX',['../bloques___b_a_c_k_u_p__9669_8cpp.html#a43fc00213652c770edd68a0d20a6668b',1,'DoblesX():&#160;bloques_BACKUP_9669.cpp'],['../bloques___b_a_c_k_u_p__9743_8cpp.html#a43fc00213652c770edd68a0d20a6668b',1,'DoblesX():&#160;bloques_BACKUP_9743.cpp'],['../bloques___r_e_m_o_t_e__9669_8cpp.html#a43fc00213652c770edd68a0d20a6668b',1,'DoblesX():&#160;bloques_REMOTE_9669.cpp'],['../bloques___r_e_m_o_t_e__9743_8cpp.html#a43fc00213652c770edd68a0d20a6668b',1,'DoblesX():&#160;bloques_REMOTE_9743.cpp']]],
  ['doblesy_228',['DoblesY',['../bloques___b_a_c_k_u_p__9669_8cpp.html#aa3d7f2cdfed3a92478d0c839fc4b538c',1,'DoblesY():&#160;bloques_BACKUP_9669.cpp'],['../bloques___b_a_c_k_u_p__9743_8cpp.html#aa3d7f2cdfed3a92478d0c839fc4b538c',1,'DoblesY():&#160;bloques_BACKUP_9743.cpp'],['../bloques___r_e_m_o_t_e__9669_8cpp.html#aa3d7f2cdfed3a92478d0c839fc4b538c',1,'DoblesY():&#160;bloques_REMOTE_9669.cpp'],['../bloques___r_e_m_o_t_e__9743_8cpp.html#aa3d7f2cdfed3a92478d0c839fc4b538c',1,'DoblesY():&#160;bloques_REMOTE_9743.cpp']]]
];
