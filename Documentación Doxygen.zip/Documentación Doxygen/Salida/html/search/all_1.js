var searchData=
[
  ['addtogroup_1',['addToGroup',['../class_comun.html#a21d96cbbb440c8bb2c603df470de8015',1,'Comun::addToGroup()'],['../class_internos.html#abe8bba4060a13bf6c3c61eff75795134',1,'Internos::addToGroup()']]],
  ['ancho_2',['ancho',['../class_raqueta.html#a6e14b951dd044e9afe6459efbdddd989',1,'Raqueta']]],
  ['anchobola_3',['anchoBola',['../class_bola.html#a0a0093cc790c407b4e0e7fe246477755',1,'Bola']]],
  ['anchoventana_4',['anchoVentana',['../ventana_8cpp.html#a5f7bfdaf44e61e39e4cd28cd00f90294',1,'anchoVentana():&#160;ventana.cpp'],['../ventana_8h.html#a5f7bfdaf44e61e39e4cd28cd00f90294',1,'anchoVentana():&#160;ventana.cpp']]],
  ['aumentarbola_5',['aumentarBola',['../class_bola.html#a50ea7afe94a6a593d89565378ef20c78',1,'Bola']]],
  ['aumentarraqueta_6',['aumentarRaqueta',['../class_raqueta.html#a8896480d20dfec4f845b2b88f23c514c',1,'Raqueta']]]
];
