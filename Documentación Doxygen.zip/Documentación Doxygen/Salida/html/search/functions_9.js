var searchData=
[
  ['paint_202',['paint',['../class_comun.html#a1b9c0f3e6b8bdaa0f121fa3333c894e9',1,'Comun::paint()'],['../class_dobles.html#a96df3dc34019ad8a2c5561f534686cb1',1,'Dobles::paint()'],['../class_internos.html#a4f2fd680fcb2e550ea799a012abd90c2',1,'Internos::paint()'],['../class_profundos.html#a811ea7bb6a5f2f2db2f3e6b934cc858a',1,'Profundos::paint()'],['../class_sorpresa.html#a8568f9a8399bcd881b784940ff3ed854',1,'Sorpresa::paint()'],['../class_triples.html#af7f6ccbe138643c508f1199478f33a77',1,'Triples::paint()']]],
  ['playsound_203',['playSound',['../class_bola.html#a89b6ee52609cf911f2340945462daa4e',1,'Bola']]],
  ['profundos_204',['Profundos',['../class_profundos.html#a7d7faa2cdeeeb7a86979db17d5dc5ba7',1,'Profundos']]]
];
