var searchData=
[
  ['iniciar_54',['Iniciar',['../class_juego.html#a6670887ef94fe76700eb7e6cfc3272a6',1,'Juego']]],
  ['interno_55',['interno',['../class_juego.html#a374ef753e6ae8034c7512c7bdbc4f583',1,'Juego']]],
  ['internos_56',['Internos',['../class_internos.html',1,'Internos'],['../class_internos.html#aeb9ed946f6f2addadbf13ba16782dc4e',1,'Internos::Internos()']]],
  ['internos_2ecpp_57',['internos.cpp',['../internos_8cpp.html',1,'']]],
  ['internos_2eh_58',['internos.h',['../internos_8h.html',1,'']]]
];
