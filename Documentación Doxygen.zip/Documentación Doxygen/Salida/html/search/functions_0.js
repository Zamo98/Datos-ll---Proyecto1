var searchData=
[
  ['addtogroup_174',['addToGroup',['../class_comun.html#a21d96cbbb440c8bb2c603df470de8015',1,'Comun::addToGroup()'],['../class_internos.html#abe8bba4060a13bf6c3c61eff75795134',1,'Internos::addToGroup()']]],
  ['aumentarbola_175',['aumentarBola',['../class_bola.html#a50ea7afe94a6a593d89565378ef20c78',1,'Bola']]],
  ['aumentarraqueta_176',['aumentarRaqueta',['../class_raqueta.html#a8896480d20dfec4f845b2b88f23c514c',1,'Raqueta']]]
];
