var searchData=
[
  ['posi_244',['posi',['../bloques___b_a_c_k_u_p__9669_8cpp.html#ae45f19b84d67b6a419f912aed65140ea',1,'posi():&#160;bloques_BACKUP_9669.cpp'],['../bloques___b_a_c_k_u_p__9743_8cpp.html#ae45f19b84d67b6a419f912aed65140ea',1,'posi():&#160;bloques_BACKUP_9743.cpp'],['../bloques___r_e_m_o_t_e__9669_8cpp.html#ae45f19b84d67b6a419f912aed65140ea',1,'posi():&#160;bloques_REMOTE_9669.cpp'],['../bloques___r_e_m_o_t_e__9743_8cpp.html#ae45f19b84d67b6a419f912aed65140ea',1,'posi():&#160;bloques_REMOTE_9743.cpp']]],
  ['profundida_245',['profundida',['../class_profundos.html#adb691bbc956bbdb2545b7e681895597e',1,'Profundos']]],
  ['profundidad_246',['profundidad',['../class_bola.html#a5d105de63056791cfe424196a1c39440',1,'Bola']]],
  ['profundo_247',['profundo',['../class_juego.html#aeba40e7fbf3c8a475f67039b763f5c3a',1,'Juego']]],
  ['profundos_248',['profundos',['../bola_8cpp.html#abc421433821ba78892e66416d48af70f',1,'bola.cpp']]],
  ['profundox_249',['ProfundoX',['../bloques___b_a_c_k_u_p__9669_8cpp.html#a917161ac8a29cf99c03c424dc305b9b2',1,'ProfundoX():&#160;bloques_BACKUP_9669.cpp'],['../bloques___b_a_c_k_u_p__9743_8cpp.html#a917161ac8a29cf99c03c424dc305b9b2',1,'ProfundoX():&#160;bloques_BACKUP_9743.cpp'],['../bloques___r_e_m_o_t_e__9669_8cpp.html#a917161ac8a29cf99c03c424dc305b9b2',1,'ProfundoX():&#160;bloques_REMOTE_9669.cpp'],['../bloques___r_e_m_o_t_e__9743_8cpp.html#a917161ac8a29cf99c03c424dc305b9b2',1,'ProfundoX():&#160;bloques_REMOTE_9743.cpp']]],
  ['profundoy_250',['ProfundoY',['../bloques___b_a_c_k_u_p__9669_8cpp.html#a57760c86a7141145380c30de48221f18',1,'ProfundoY():&#160;bloques_BACKUP_9669.cpp'],['../bloques___b_a_c_k_u_p__9743_8cpp.html#a57760c86a7141145380c30de48221f18',1,'ProfundoY():&#160;bloques_BACKUP_9743.cpp'],['../bloques___r_e_m_o_t_e__9669_8cpp.html#a57760c86a7141145380c30de48221f18',1,'ProfundoY():&#160;bloques_REMOTE_9669.cpp'],['../bloques___r_e_m_o_t_e__9743_8cpp.html#a57760c86a7141145380c30de48221f18',1,'ProfundoY():&#160;bloques_REMOTE_9743.cpp']]],
  ['puntos_251',['puntos',['../class_juego.html#a3c07b96c2718cd87757eeb025c1276ea',1,'Juego']]]
];
