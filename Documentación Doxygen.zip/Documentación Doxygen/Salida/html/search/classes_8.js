var searchData=
[
  ['triples_134',['Triples',['../class_triples.html',1,'']]]
];
