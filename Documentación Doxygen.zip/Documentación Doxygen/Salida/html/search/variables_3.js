var searchData=
[
  ['comun_222',['comun',['../class_juego.html#a550d48b5165f5e82c7b367a41cd7138c',1,'Juego']]],
  ['comunesx_223',['ComunesX',['../bloques___b_a_c_k_u_p__9669_8cpp.html#abda2f857a33e37628b12ac69cf24f508',1,'ComunesX():&#160;bloques_BACKUP_9669.cpp'],['../bloques___b_a_c_k_u_p__9743_8cpp.html#abda2f857a33e37628b12ac69cf24f508',1,'ComunesX():&#160;bloques_BACKUP_9743.cpp'],['../bloques___r_e_m_o_t_e__9669_8cpp.html#abda2f857a33e37628b12ac69cf24f508',1,'ComunesX():&#160;bloques_REMOTE_9669.cpp'],['../bloques___r_e_m_o_t_e__9743_8cpp.html#abda2f857a33e37628b12ac69cf24f508',1,'ComunesX():&#160;bloques_REMOTE_9743.cpp']]],
  ['comunesy_224',['ComunesY',['../bloques___b_a_c_k_u_p__9669_8cpp.html#ad55d34adf56f87e610dd7cb765963aa2',1,'ComunesY():&#160;bloques_BACKUP_9669.cpp'],['../bloques___b_a_c_k_u_p__9743_8cpp.html#ad55d34adf56f87e610dd7cb765963aa2',1,'ComunesY():&#160;bloques_BACKUP_9743.cpp'],['../bloques___r_e_m_o_t_e__9669_8cpp.html#ad55d34adf56f87e610dd7cb765963aa2',1,'ComunesY():&#160;bloques_REMOTE_9669.cpp'],['../bloques___r_e_m_o_t_e__9743_8cpp.html#ad55d34adf56f87e610dd7cb765963aa2',1,'ComunesY():&#160;bloques_REMOTE_9743.cpp']]],
  ['contador_225',['contador',['../class_juego.html#aa1b02a0c5aacd7001acd76e984b7b945',1,'Juego']]]
];
