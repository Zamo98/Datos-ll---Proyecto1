var searchData=
[
  ['interno_236',['interno',['../class_juego.html#a374ef753e6ae8034c7512c7bdbc4f583',1,'Juego']]]
];
