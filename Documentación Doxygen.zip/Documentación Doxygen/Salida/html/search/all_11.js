var searchData=
[
  ['velocidadx_115',['velocidadX',['../class_bola.html#aa941a075f38c3285984aff29bfb5f0da',1,'Bola']]],
  ['velocidady_116',['velocidadY',['../class_bola.html#a1c502b8f15fa823a53dafdbd34fd4d57',1,'Bola']]],
  ['ventana_117',['Ventana',['../class_ventana.html',1,'Ventana'],['../class_ventana.html#a890557b1c517d9b890dcb2e9663a558c',1,'Ventana::Ventana()']]],
  ['ventana_2ecpp_118',['ventana.cpp',['../ventana_8cpp.html',1,'']]],
  ['ventana_2eh_119',['ventana.h',['../ventana_8h.html',1,'']]],
  ['vida_120',['Vida',['../class_dobles.html#a18c71ff663ed19c0950e28cdbf43a54d',1,'Dobles::Vida()'],['../class_triples.html#a00680b8a82a212d1e9f99bf533e161f7',1,'Triples::Vida()']]],
  ['vidas_121',['Vidas',['../class_dobles.html#a54be0e197995fd3c1eee0a4d74ef608e',1,'Dobles::Vidas()'],['../class_triples.html#ae533cc41916ae2b14bacb44dcae98ba2',1,'Triples::Vidas()']]],
  ['vx_122',['vX',['../class_bola.html#af4c72f502892a6128aa625d77001bb92',1,'Bola']]],
  ['vy_123',['vY',['../class_bola.html#acc566694008bb3465778acc012e99ba6',1,'Bola']]]
];
