var searchData=
[
  ['disparo_185',['disparo',['../class_raqueta.html#a3abfc17fce70eeb7bb6ed290323cef56',1,'Raqueta']]],
  ['dobles_186',['Dobles',['../class_dobles.html#a0f90f9815301f099b14a1bcaa209151e',1,'Dobles']]]
];
